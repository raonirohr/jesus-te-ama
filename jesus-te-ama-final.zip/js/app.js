const progress = document.getElementById("progress");
if (progress) {
  window.addEventListener("scroll", () => {
    const h = document.documentElement;
    const scrolled = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100;
    progress.style.width = scrolled + "%";
  });
}
const obs = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) entry.target.classList.add("show");
  });
}, { threshold: 0.12 });
document.querySelectorAll(".reveal").forEach((el) => obs.observe(el));

const shareBtn = document.getElementById("shareBtn");
const copyBtn = document.getElementById("copyBtn");
if (shareBtn) {
  shareBtn.addEventListener("click", async () => {
    const data = {
      title: "Jesus Te Ama",
      text: "Você não chegou aqui por acaso. Conheça a maior história de amor já contada.",
      url: window.location.href
    };
    if (navigator.share) await navigator.share(data);
    else navigator.clipboard.writeText(window.location.href);
  });
}
if (copyBtn) {
  copyBtn.addEventListener("click", async () => {
    await navigator.clipboard.writeText(window.location.href);
    copyBtn.textContent = "Link copiado";
    setTimeout(() => copyBtn.textContent = "Copiar link", 1800);
  });
}
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("service-worker.js").catch(() => {}));
}
